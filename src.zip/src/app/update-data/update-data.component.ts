import { Component, OnInit } from '@angular/core';
import { DataServicesService } from '../data-services.service';

interface Records
{
  id:number;
  name:string;
  email:string;
  contact:string;
  address:string;
}
@Component({
  selector: 'app-update-data',
  templateUrl: './update-data.component.html',
  styleUrls: ['./update-data.component.css']
})
export class UpdateDataComponent implements OnInit {

  id:number;
  users:Records[];
  updatedat:Records[]=[{id:0,name:"",email:"",contact:"",address:""}];
  constructor() {
      this.users=JSON.parse(localStorage.getItem("users")||"[]");
   }

  ngOnInit(): void {
    this.id=Number(localStorage.getItem("id"));
    for(let i=0;i<this.users.length;i++)
    {
      if(this.users[i].id==this.id)
      {
        this.updatedat[0].id=this.users[i].id;
        this.updatedat[0].name=this.users[i].name;
        this.updatedat[0].email=this.users[i].email;
        this.updatedat[0].contact=this.users[i].contact;
        this.updatedat[0].address=this.users[i].address;
        console.log("ID :"+this.id);
      }
    }
    
  }


}
