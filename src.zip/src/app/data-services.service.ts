import { Injectable } from '@angular/core';

interface Records
{
  id:number;
  name:string;
  email:string;
  contact:string;
  address:string;
}

@Injectable({
  providedIn: 'root'
})
export class DataServicesService {
  users:Records[]=[
    {id:1,name:"Eshwar",email:"es@gmail.com",contact:"9743496260",address:"Bangalore"},
    {id:2,name:"Shivam",email:"sk@gmail.com",contact:"9743496261",address:"Karnataka"},
    {id:3,name:"Dilnayab",email:"dil@gmail.com",contact:"9743496261",address:"Karnataka"}
  ];
  constructor() { }
  getUsersList()
  {
    return this.users;
  }
}
